package com.capgemini.capstore.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapStore201ChangeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapStore201ChangeApplication.class, args);
	}

}
