package com.capgemini.capstore.main.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.main.beans.Offer;
import com.capgemini.capstore.main.beans.Product;
import com.capgemini.capstore.main.dao.CapStoreMerchant;
import com.capgemini.capstore.main.dao.CapStoreOffer;
import com.capgemini.capstore.main.dao.CapStoreProduct;

@Service
public class ApplyDiscountServiceImpl implements ApplyDiscountService {
	
	@Autowired
	private CapStoreMerchant capStoreMerchant;
	
	@Autowired
	private CapStoreProduct capStoreProduct;
	
	@Autowired
	private CapStoreOffer capStoreOffer;

	
	@Override
	public List<Offer> applyOfferByCategory(int merchantId,String productCategory,String offerDescription, Date offerStartDate, Date offerEndDate,double discountOffered,String softDelete) {
		List<Product> products=capStoreProduct.findByProductCategory(productCategory);
		List<Offer> offers=new ArrayList<>();
		for(Product product:products)
		{
		Offer offer = new Offer();
		offer.setMerchant(capStoreMerchant.findById(merchantId).get());
		offer.setProduct(product);
//		offer.setOfferId(offerId);
		offer.setOfferDescription(offerDescription);
		offer.setOfferStartDate(offerStartDate);
		offer.setOfferEndDate(offerEndDate);
		offer.setDiscountOffered(discountOffered);
		offer.setSoftDelete(softDelete);
		System.out.println(offer);
		capStoreOffer.save(offer);
		offers.add(offer);
		}
		return offers;
	}
	
	
	
	
	@Override
	public Offer applyOffer(int merchantId,int productid,String offerDescription, Date offerStartDate, Date offerEndDate,double discountOffered,String softDelete) {
		
		Offer offer = new Offer();
		offer.setMerchant(capStoreMerchant.findById(merchantId).get());
		offer.setProduct(capStoreProduct.findById(productid).get());
//		offer.setOfferId(offerId);
		offer.setOfferDescription(offerDescription);
		offer.setOfferStartDate(offerStartDate);
		offer.setOfferEndDate(offerEndDate);
		offer.setDiscountOffered(discountOffered);
		offer.setSoftDelete(softDelete);
		capStoreOffer.save(offer);
		return offer;
	}
	
	

}
