package com.capgemini.capstore.main.controller;

import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.expression.ParseException;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.main.beans.Offer;
import com.capgemini.capstore.main.service.ApplyDiscountService;


@RestController
public class CapStoreController {
	
	@Autowired
	ApplyDiscountService applyDiscountService;
/*	
	@RequestMapping(value="/createOffer/{merchantId}/{productid}/{offerDescription}/{offerStartDate}/{offerEndDate}/{discountOffered}/{softDelete}",method=RequestMethod.GET)
	public Offer applyOffer(@PathVariable int merchantId,@PathVariable int productid,@PathVariable String offerDescription,@PathVariable String offerStartDate,@PathVariable String offerEndDate,@PathVariable double discountOffered,@PathVariable String softDelete) throws ParseException, java.text.ParseException
	{
		SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy");
		return applyDiscountService.applyOffer(merchantId, productid, offerDescription, formatter.parse(offerStartDate),formatter.parse(offerEndDate), discountOffered, softDelete);
		
	}*/
	
	
	@RequestMapping(value="/createOffer",method=RequestMethod.POST)
	public Offer applyOfferByPostMethod(@RequestBody Offer offer) throws ParseException, java.text.ParseException
	{
		return applyDiscountService.applyOffer(offer.getMerchant().getMerchantId(),offer.getProduct().getProductId(),offer.getOfferDescription(), offer.getOfferStartDate(),offer.getOfferEndDate(), offer.getDiscountOffered(),offer.getSoftDelete());
		
	}
	
	
	@RequestMapping(value="/createOfferbyCategory",method=RequestMethod.POST)
	public List<Offer> applyOfferByCategoryusingPost(@RequestBody Offer offer) throws ParseException, java.text.ParseException
	{
		return applyDiscountService.applyOfferByCategory(offer.getMerchant().getMerchantId(),offer.getProduct().getProductCategory(),offer.getOfferDescription(), offer.getOfferStartDate(),offer.getOfferEndDate(), offer.getDiscountOffered(),offer.getSoftDelete());
		
	}
	
	/*
	@RequestMapping(value="/createOfferByCategory/{merchantId}/{Category}/{offerDescription}/{offerStartDate}/{offerEndDate}/{discountOffered}/{softDelete}",method=RequestMethod.GET)
	public List<Offer> applyOfferByCategory(@PathVariable int merchantId,@PathVariable String Category,@PathVariable String offerDescription,@PathVariable String offerStartDate,@PathVariable String offerEndDate,@PathVariable double discountOffered,@PathVariable String softDelete) throws ParseException, java.text.ParseException
	{
		SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy");
		return applyDiscountService.applyOfferByCategory(merchantId, Category, offerDescription, formatter.parse(offerStartDate),formatter.parse(offerEndDate), discountOffered, softDelete);
		
	}*/
	
	

	
}
