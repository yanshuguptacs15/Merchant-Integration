package com.capgemini.capstore.main.service;

import java.util.Date;
import java.util.List;

import com.capgemini.capstore.main.beans.Offer;
public interface ApplyDiscountService {
	public Offer applyOffer(int merchantId,int category,String offerDescription, Date offerStartDate, Date offerEndDate,double discountOffered,String softDelete);

	List<Offer> applyOfferByCategory(int merchantId, String productCategory, String offerDescription, Date offerStartDate,
			Date offerEndDate, double discountOffered, String softDelete);
	

}
