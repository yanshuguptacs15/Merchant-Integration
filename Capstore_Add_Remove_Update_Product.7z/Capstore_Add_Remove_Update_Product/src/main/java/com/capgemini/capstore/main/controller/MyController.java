package com.capgemini.capstore.main.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.main.beans.Product;
import com.capgemini.capstore.main.service.IMerchantService;

@RestController
public class MyController {

	@Autowired
	IMerchantService service;

	@RequestMapping(method = RequestMethod.GET, value = "/getProduct/{productId}")
	public Product getProduct(@PathVariable int productId, HttpServletRequest request) {
		// HttpSession session = request.getSession();
		// if(session.getAttribute("role").equals("MERCHANT")){
		String merchantEmail = "yanshu@gupta.com";// session.getAttribute("userId");
		
		return service.getProduct(productId, merchantEmail);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/addProduct")
	public Product addProduct(@Valid @RequestBody Product product, HttpServletRequest request) {
		// HttpSession session = request.getSession();
		// if(session.getAttribute("role").equals("MERCHANT")){
		String merchantEmail = "yanshu@gupta.com";// session.getAttribute("userId");

		return service.addProduct(product, merchantEmail);
		// return "Successfull Add Product";
		/*
		 * } else{ return "errorPage"; }
		 */
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/updateProduct/{productId}")
	public Product updateProduct(@Valid @RequestBody Product product, @PathVariable int productId) {
		// HttpSession session = request.getSession();
		// if(session.getAttribute("role").equals("MERCHANT")){
		String merchantEmail = "yanshu@gupta.com";// session.getAttribute("userId");
		product.setProductId(productId);
		service.updateProduct(product, merchantEmail);
		return product;
		// return "Successfull Add Product";
		/*
		 * } else{ return "errorPage"; }
		 */
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/removeProduct/{productId}")
	public boolean removeProduct(@PathVariable int productId) {
		// HttpSession session = request.getSession();
		// if(session.getAttribute("role").equals("MERCHANT")){
		String merchantEmail = "yanshu@gupta.com";// session.getAttribute("userId");
		
		return service.removeProduct(productId, merchantEmail);
		
		// return "Successfull Add Product";
		/*
		 * } else{ return "errorPage"; }
		 */
	}

}
