package com.capgemini.capstore.main.service;

import javax.validation.Valid;

import com.capgemini.capstore.main.beans.Product;

public interface IMerchantService {

	Product addProduct(@Valid Product product, String merchantEmail);

	Product updateProduct(@Valid Product product, String merchantEmail);

	Product getProduct(int productId, String merchantEmail);

	boolean removeProduct(int productId, String merchantEmail);

	


}
