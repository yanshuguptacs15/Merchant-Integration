package com.capgemini.capstore.main.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.capstore.beans.Feedback;

public interface CapStoreFeedback extends JpaRepository<Feedback, Integer>{

}
