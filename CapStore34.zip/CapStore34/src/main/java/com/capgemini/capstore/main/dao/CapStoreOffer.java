package com.capgemini.capstore.main.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.main.beans.Merchant;
import com.capgemini.capstore.main.beans.Offer;
import com.capgemini.capstore.main.beans.Product;

@Repository
public interface CapStoreOffer extends JpaRepository<Offer, Integer>{

//	@Query(value="select * from offer where merchant_merchant_id=:mid and product_product_id=:pid", nativeQuery=true)
//	public Offer findByMerchantAndProduct(@Param("mid") int mid, @Param("pid")int pid);
//	@Query("SELECT o FROM Offer o where o.merchant = :merchant") 
//    List<Offer> findByMerchant(@Param("merchant")int merchant);
//	List<Offer> findByMerchant(Merchant merchant);
	List<Offer> findByMerchantAndProduct(Merchant merchant, Product product);
}
