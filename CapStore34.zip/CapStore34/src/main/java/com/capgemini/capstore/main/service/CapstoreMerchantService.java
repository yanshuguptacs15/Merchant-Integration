package com.capgemini.capstore.main.service;

public interface CapstoreMerchantService {
	
//	public double applyDiscount(int merchantId, int productId);
//	public List<Offer> findByMerchant(int merchantId);
	public double findByMerchantAndProduct(int merchantId,int productId);

}
