package com.capgemini.capstore.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.main.beans.Merchant;
import com.capgemini.capstore.main.beans.Offer;
import com.capgemini.capstore.main.beans.Product;
import com.capgemini.capstore.main.dao.CapStoreMerchant;
import com.capgemini.capstore.main.dao.CapStoreOffer;
import com.capgemini.capstore.main.dao.CapStoreProduct;

@Service
public class CapstoreMerchantServiceImpl implements CapstoreMerchantService {
	
	@Autowired
	CapStoreOffer capStoreOffer;
	
	@Autowired
	CapStoreMerchant capStoreMerchant;
	
	@Autowired
	CapStoreProduct capStoreProduct;
	
//	@Override
//	public double applyDiscount(int merchantId, int productId) {
//		
//		Offer offer=capStoreOffer.findByMerchantAndProduct(merchantId, productId);
//		return offer.getDiscountOffered();
//	}
//
//
//	@Override
//	public List<Offer> findByMerchant(int merchantId) {
//		Merchant merchant=capStoreMerchant.findById(merchantId).get();
//		System.out.println(merchant);
//		List<Offer> offer=capStoreOffer.findByMerchant(merchant);
//		
//		return offer;
//	}
	
	
	@Override
	public double findByMerchantAndProduct(int merchantId,int productId)
	{
		Merchant merchant=capStoreMerchant.findById(merchantId).get();	
		Product product=capStoreProduct.findById(productId).get();
		double productMRP=product.getProductPrice();
		List<Offer> offerlist=capStoreOffer.findByMerchantAndProduct(capStoreMerchant.findById(merchantId).get(),capStoreProduct.findById(productId).get());
		for(Offer offer:offerlist)
		{
			if(offer.getSoftDelete().equals("A"))
			{
			double discount=offer.getDiscountOffered();
			double finalPrice=(productMRP*(100-discount)/100);
			return finalPrice;
			}
		}
		return productMRP;
	}
		
	

}
