package com.capgemini.capstore.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.main.service.CapstoreMerchantService;

@RestController
public class CapStoreController {
	
	@Autowired
	CapstoreMerchantService cap;
	
	
//	@RequestMapping(value="/test/{merchantId}/{productId}")
//	public double getDiscount(@PathVariable int merchantId,@PathVariable int productId)
//	{
//		return cap.applyDiscount(merchantId, productId);
//		
//	}
//
//	@RequestMapping(value="/getOfferByMerchant/{merchantId}")
//	public List<Offer> getMerchant(@PathVariable int merchantId)
//	{
//		return cap.findByMerchant(merchantId);
//		
//	}
	
	@RequestMapping(value="/getOfferByMerchantAndProduct/{merchantId}/{productId}")
	public double getMerchantAndProduct(@PathVariable int merchantId,@PathVariable int productId)
	{
		return cap.findByMerchantAndProduct(merchantId,productId);
		
	}
	
	
	
	@RequestMapping(value="/test")
	public String test()
	{
		return "test";
	}
	
	

	
	
}
