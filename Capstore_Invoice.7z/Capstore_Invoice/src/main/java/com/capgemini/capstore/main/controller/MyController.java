package com.capgemini.capstore.main.controller;


import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.main.beans.Order;
import com.capgemini.capstore.main.service.IMerchantService;

@RestController
public class MyController {

	@Autowired
	IMerchantService service;
	
	@RequestMapping(method = RequestMethod.GET, value = "/invoice/{orderId}")
	public Order addProduct(@PathVariable int orderId, HttpServletRequest request) {
		//HttpSession session = request.getSession();
		String userId = "yanshu@gmail.com";//(String)session.getAttribute("userId");
		return service.findOrder(userId,orderId);
		//return new ModelAndView("error", "order", order);

	}

	
}
