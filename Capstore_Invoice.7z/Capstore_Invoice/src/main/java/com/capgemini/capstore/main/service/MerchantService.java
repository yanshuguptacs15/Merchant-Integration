package com.capgemini.capstore.main.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.main.beans.Order;
import com.capgemini.capstore.main.dao.CapStoreOrder;

@Service
public class MerchantService implements IMerchantService {
	
	@Autowired
	CapStoreOrder orderRepo;
	
	@Override
	public Order findOrder(String userId, int orderId) {
		
		Order order = orderRepo.findById(orderId).get();
		
		if(order.getCustomer().getCustomerEmail().equals(userId)) {
			return order;
		}
		return null;
	}


	

}
