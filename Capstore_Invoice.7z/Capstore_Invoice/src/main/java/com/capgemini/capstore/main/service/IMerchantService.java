package com.capgemini.capstore.main.service;

import com.capgemini.capstore.main.beans.Order;

public interface IMerchantService {

	Order findOrder(String userId, int orderId);

}
