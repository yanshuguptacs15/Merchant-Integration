package com.capgemini.capstore.main.exception;

public class InvalidLogInCredential extends RuntimeException {

}
