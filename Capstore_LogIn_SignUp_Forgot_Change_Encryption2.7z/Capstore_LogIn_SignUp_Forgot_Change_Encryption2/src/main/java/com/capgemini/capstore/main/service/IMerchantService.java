package com.capgemini.capstore.main.service;

import javax.validation.Valid;

import com.capgemini.capstore.main.beans.Customer;
import com.capgemini.capstore.main.beans.Merchant;
import com.capgemini.capstore.main.beans.User;

public interface IMerchantService {

	boolean ValidateLogIn(User user);

	Merchant getMerchant(int merchantId);

	boolean ValidateUserDetails(@Valid User user);

	Customer ValidateCustomerDetails(@Valid Customer customer);

	Merchant ValidateMerchantDetails(@Valid Merchant merchant);

	boolean isValidResetPasswordRequest(String email);

	String isValidEmail(String email);

	void updatePassword(String email, String password);

	boolean checkSequirityAnswer(String email, String sequirityAnswer);

	boolean changePassword(String email, String oldPassword, String newPassword);

}
