package com.capgemini.capstore.service;

import java.util.List;

import com.capgemini.capstore.beans.Order;

public interface CapstoreOrderService {
	public Order search(int orid);


	String getStatus(int id);
	

}
