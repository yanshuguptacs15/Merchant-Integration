package com.capgemini.capstore.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.dao.CapStoreOrder;

@Service
public class CapstoreServiceImpl implements CapstoreOrderService {
	@Autowired
	CapStoreOrder capDao;
	
	

	@Override
	public Order search(int orid) {

		return capDao.findById(orid).get();
		

	}
	@Override
	public String getStatus(int id) {
		String status = null;//new ArrayList<>();
		List<Order> orders =  capDao.findAll();
		for(Order i: orders)
		{
			if(i.getCustomer().getCustomerId() == id)
			{
				status=i.getDeliveryStatus();
			}
		}
		return status;
	}

}
