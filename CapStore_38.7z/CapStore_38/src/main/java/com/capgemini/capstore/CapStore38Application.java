package com.capgemini.capstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapStore38Application {

	public static void main(String[] args) {
		SpringApplication.run(CapStore38Application.class, args);
	}

}
